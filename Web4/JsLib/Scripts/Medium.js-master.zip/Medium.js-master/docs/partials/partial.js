new Medium({
    element: document.getElementById('comment'),
    mode: Medium.partialMode,
    placeholder: 'Your Comment'
});
new Medium({
    element: document.getElementById('title'),
    mode: Medium.inlineMode,
    maxLength: 25,
    placeholder: 'Your Title'
});
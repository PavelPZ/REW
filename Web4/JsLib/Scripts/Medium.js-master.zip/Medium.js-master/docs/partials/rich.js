new Medium({
    element: document.getElementById('article'),
    mode: Medium.richMode,
    placeholder: 'Your Article'
});
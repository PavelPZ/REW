var rangy = require("rangy-browser/lib/rangy-core");
console.log(rangy);